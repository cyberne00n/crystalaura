package com.example.crystalaura;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import java.util.Optional;

/**
 * Crystal HUD + тренировочный авто-удар.
 * H: показать/скрыть панель.
 * J: авто-удар по кристаллам рядом (ТОЛЬКО в одиночной игре, на серверах сам выключается).
 */
public class CrystalHudClient implements ClientModInitializer {
    private static final double SCAN_RANGE = 12.0; // дальше взрыв не наносит урона
    private static final double HIT_RANGE = 4.5;   // радиус авто-удара
    private static final int HIT_DELAY_TICKS = 2;  // пауза между ударами

    private static KeyBinding toggleKey;
    private static KeyBinding trainKey;
    private static boolean visible = true;
    private static boolean autoHit = false;
    private static int cooldown = 0;

    @Override
    public void onInitializeClient() {
        // В 1.21.9+ у клавиш есть категория (KeyBinding.Category)
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("crystalaura", "main"));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.crystalaura.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, category));
        trainKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.crystalaura.train", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, category));

        ClientTickEvents.END_CLIENT_TICK.register(CrystalHudClient::onTick);

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.CHAT,
                Identifier.of("crystalaura", "hud"),
                (context, tickCounter) -> render(context));
    }

    private static void onTick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            visible = !visible;
        }

        while (trainKey.wasPressed()) {
            if (!client.isInSingleplayer()) {
                autoHit = false;
                notify(client, "Авто-удар работает только в одиночной игре");
            } else {
                autoHit = !autoHit;
                notify(client, "Авто-удар (тренировка): " + (autoHit ? "ВКЛ" : "ВЫКЛ"));
            }
        }

        if (!autoHit) return;

        // Защита: вышли из одиночного мира, сразу выключаемся
        if (client.player == null || client.world == null
                || client.interactionManager == null || !client.isInSingleplayer()) {
            autoHit = false;
            return;
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        client.world.getEntitiesByClass(
                        EndCrystalEntity.class,
                        client.player.getBoundingBox().expand(HIT_RANGE),
                        e -> e.isAlive() && client.player.distanceTo(e) <= HIT_RANGE)
                .stream()
                .min(Comparator.comparingDouble(client.player::distanceTo))
                .ifPresent(target -> {
                    client.interactionManager.attackEntity(client.player, target);
                    client.player.swingHand(Hand.MAIN_HAND);
                    cooldown = HIT_DELAY_TICKS;
                });
    }

    private static void notify(MinecraftClient client, String message) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(message), true);
        }
    }

    private static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!visible || client.player == null || client.world == null || client.options.hudHidden) return;

        int crystals = 0;
        int obsidian = 0;
        for (int i = 0; i < client.player.getInventory().size(); i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (stack.isOf(Items.END_CRYSTAL)) crystals += stack.getCount();
            else if (stack.isOf(Items.OBSIDIAN)) obsidian += stack.getCount();
        }

        Optional<EndCrystalEntity> nearest = client.world.getEntitiesByClass(
                        EndCrystalEntity.class,
                        client.player.getBoundingBox().expand(SCAN_RANGE),
                        e -> e.isAlive())
                .stream()
                .min(Comparator.comparingDouble(client.player::distanceTo));

        int x = 6;
        int y = 6;
        int line = 11;

        context.drawTextWithShadow(client.textRenderer, Text.literal("Crystal HUD"), x, y, 0xFFC77DFF);
        context.drawTextWithShadow(client.textRenderer,
                Text.literal("Кристаллы: " + crystals), x, y + line, 0xFFFFFFFF);
        context.drawTextWithShadow(client.textRenderer,
                Text.literal("Обсидиан: " + obsidian), x, y + line * 2, 0xFFFFFFFF);
        context.drawTextWithShadow(client.textRenderer,
                Text.literal("Авто-удар: " + (autoHit ? "ВКЛ" : "ВЫКЛ")),
                x, y + line * 3, autoHit ? 0xFF55FF55 : 0xFFAAAAAA);

        if (nearest.isPresent()) {
            float dist = client.player.distanceTo(nearest.get());
            float damage = estimateDamage(dist);
            float health = client.player.getHealth() + client.player.getAbsorptionAmount();
            boolean lethal = damage >= health;

            context.drawTextWithShadow(client.textRenderer,
                    Text.literal(String.format("Ближайший кристалл: %.1f м", dist)),
                    x, y + line * 4, 0xFFFFFFFF);
            context.drawTextWithShadow(client.textRenderer,
                    Text.literal(String.format("Урон от взрыва: ~%.1f%s", damage, lethal ? "  СМЕРТЕЛЬНО!" : "")),
                    x, y + line * 5, lethal ? 0xFFFF5555 : (damage > 8 ? 0xFFFFAA00 : 0xFF55FF55));
        } else {
            context.drawTextWithShadow(client.textRenderer,
                    Text.literal("Кристаллов рядом нет"), x, y + line * 4, 0xFFAAAAAA);
        }
    }

    /**
     * Грубая оценка урона от взрыва кристалла (сила 6), как в ванильной формуле,
     * но без учёта брони, зачарований, эффектов, препятствий и сложности.
     */
    private static float estimateDamage(float distance) {
        double d = distance / 12.0;
        if (d > 1.0) return 0f;
        double impact = 1.0 - d;
        return (float) (((impact * impact + impact) / 2.0 * 7.0 * 12.0) + 1.0);
    }
}
